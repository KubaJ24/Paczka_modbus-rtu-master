*Dla instalacji ręcznej*
Przed zainstalowaniem nadać uprawnienia do wykonywania:
sudo chmod +x build_deb.sh

Instalacja:
sudo dpkg -i modbus-rtu-master-wersja.deb
sudo dpkg -i modbus-rtu-master-0.9.1.deb

Uruchomienie programu:
modbus-rtu-master

*Do instalacji z repozytorium*
Przed instalacją włączyć widoczność w GH Pages i poczekać na link jak na dole

Instalacja:
echo "deb [trusted=yes] https://kubaj24.github.io/Paczka_modbus-rtu-master stable main" | sudo tee /etc/apt/sources.list.d/modbus.list
sudo apt update
sudo apt install modbus-rtu-master

Uruchomienie programu:
modbus-rtu-master
