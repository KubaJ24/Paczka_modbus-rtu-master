Przed zainstalowaniem nadać uprawnienia do wykonywania:
sudo chmod +x build_deb.sh

Instalacja:
sudo dpkg -i modbus-rtu-master-wersja.deb
sudo dpkg -i modbus-rtu-master-0.9.1.deb

Uruchomienie programu:
modbus-rtu-master

